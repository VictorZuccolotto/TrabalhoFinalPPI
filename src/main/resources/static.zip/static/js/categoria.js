const aproveita = {
    data() {
        return {
            anuncios: [],
            url: 'http://localhost:8080/anuncio?id=',
            url2: 'http://localhost:8080/imagem/',
            nome: window.location.href.split('nome=')[1],
        }
    },
    mounted() {
        axios
        .get('http://localhost:8080/anuncio/cat/' + this.nome)
        .then(response => {
                this.anuncios = response.data
                console.log(this.anuncios)
            }
            )
    },
    methods:{
        anuncioLink(id){
            return this.url + id
        },
        imagem(id){
			return this.url2 + id
		}
    }
}
Vue.createApp(aproveita).mount('#app');
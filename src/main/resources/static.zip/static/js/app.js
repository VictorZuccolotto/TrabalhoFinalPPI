const aproveita = {
    data() {
        return {
            produtos: [],
            url: 'http://localhost:8080/anuncio?id=',
            url2: 'http://localhost:8080/imagem/'
        }
    },
    mounted() {
        axios
        .get('http://localhost:8080/anuncio/anunciosRecentes')
        .then(response => {
                this.produtos = response.data
            }
            )
    },
    methods:{
        anuncio(id){
            return this.url + id
        },
        imagem(id){
			return this.url2 + id
		}
    }
}
Vue.createApp(aproveita).mount('#app');
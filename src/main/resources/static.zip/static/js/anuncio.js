const anuncio = {
	data() {
		return {
			anuncio: [],
			url: 'http://localhost:8080/imagem/0',
			id: window.location.href.split('id=')[1],
		}
	},
	mounted() {
		axios
			.get('http://localhost:8080/anuncio/info/'+this.id)
			.then(response => {
//				response.data.forEach(resp => {
//					if (resp.idUser == 1) {
						this.anuncio = response.data
						this.url += this.anuncio.id
//						axios
//							.get('http://localhost:8080/usuarios.json')
//							.then(rsp => {
//								rsp.data.forEach(rp => {
//									if(rp.id == resp.idUser){
//										this.user = rp
//									}
//								})
//							})
//					}

//				})
			})
	},
	methods: {
		whatsapp(){
			 return "https://api.whatsapp.com/send?phone=" + this.anuncio.telefone + "&text=Gostaria+de+saber+mais+sobre+"+ this.anuncio.nome +" anunciado na Aproveita"
		}
//		,
//		imagem(id){
//			return this.url + id
//		}
	}
}
Vue.createApp(anuncio).mount('#anuncio');